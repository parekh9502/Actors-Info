//
//  ActorListViewController.swift
//  RestDataDemoCode
//
//  Created by Pritesh Parekh on 08/07/16.
//  Copyright © 2016 Pritesh Parekh. All rights reserved.
//

import UIKit

class ActorListViewController: UIViewController,UITableViewDataSource {

    @IBOutlet weak var tblview: UITableView!
    var actorArray: Array<[String:Any]> = []
    var refresh = UIRefreshControl()
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        tblview.tableFooterView = UIView()
        refresh.isEnabled = true
        refresh.tintColor = UIColor.black
        refresh.addTarget(self, action: #selector(ActorListViewController.refreshAction(_:)), for: .valueChanged)
        self.tblview.addSubview(refresh)
        getApiCallForActors()
    }
    func refreshAction(_ sender:Any)  {
        actorArray.removeAll()
        getApiCallForActors()
        print("hello")
    }

    func getApiCallForActors() {
        
        let urlRequest = URL(string: urlString)
        
        URLSession.shared.dataTask(with: urlRequest!) { (data, response, error) in
            
            if error == nil{
                
                do{
                    if let jsonResult =  try JSONSerialization.jsonObject(with: data!, options:[]) as? Dictionary<String, Any>{
                        
                        guard let arr = jsonResult["actors"] as? [[String:Any]] else{
                           return
                        }
                        self.actorArray = arr
                        DispatchQueue.main.sync {
                            self.refresh.endRefreshing()

                            self.tblview.reloadData()
                        }
                    }
                }catch{
                    print(error)
                }
                
            }
            
        }.resume()
        
        
    }
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
       
    }

    
    
     func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        // #warning Incomplete implementation, return the number of rows
        return actorArray.count
    }

    
     func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "Basic", for: indexPath)
         let  dict = actorArray[indexPath.row] as Dictionary
         cell.textLabel?.text = dict["name"] as! String?
        // Configure the cell...

        return cell
    }
    

}
