//
//  SecondViewController.swift
//  RestDataDemoCode
//
//  Created by Pritesh Parekh on 08/07/16.
//  Copyright © 2016 Pritesh Parekh. All rights reserved.
//

import UIKit

class SecondViewController: UIViewController,UITableViewDataSource {

    @IBOutlet weak var tblview: UITableView!
    var actorArray: Array<Actor> = []
    var refresh = UIRefreshControl()
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        tblview.tableFooterView = UIView()
        refresh.isEnabled = true
        refresh.tintColor = UIColor.black
        refresh.addTarget(self, action: #selector(ActorListViewController.refreshAction(_:)), for: .valueChanged)
        tblview.addSubview(refresh)
        tblview.rowHeight = UITableViewAutomaticDimension
        tblview.estimatedRowHeight  = 70
        
        getApiCallForActors()
    }
    func refreshAction(_ sender:Any)  {
        actorArray.removeAll()
        getApiCallForActors()
        print("hello")
    }
    
    func getApiCallForActors() {
        
        WebServiceHandler.sharedInstance.getActorArray { (actorArra) in
            if let arr = actorArra as? [Actor]{
                self.actorArray = arr
                DispatchQueue.main.async {
                    self.refresh.endRefreshing()
                    self.tblview.reloadData()
                }
                
            }
            
        }
        
        
    }
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    // MARK: - Table view data source
    
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        // #warning Incomplete implementation, return the number of rows
        return actorArray.count
    }
    
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "Basic", for: indexPath) as! ActorTableViewCell
        let  actor = actorArray[indexPath.row]
        cell.lblName?.text = actor.name
        if indexPath.row == 1 {
            cell.lblDesc?.text = "hello testing"
        }else{
            cell.lblDesc?.text = actor.descripton

        }

        // Configure the cell...
        
        return cell
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
